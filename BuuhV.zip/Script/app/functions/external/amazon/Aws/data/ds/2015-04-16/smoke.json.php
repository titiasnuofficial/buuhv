<?php
// This file was auto-generated from sdk-root/src/data/ds/2015-04-16/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeDirectories', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'CreateDirectory', 'input' => [ 'Name' => '', 'Password' => '', 'Size' => '', ], 'errorExpectedFromService' => true, ], ],];
