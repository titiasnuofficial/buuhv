<?php
// This file was auto-generated from sdk-root/src/data/cloud9/2017-09-23/paginators-1.json
return [ 'pagination' => [ 'DescribeEnvironmentMemberships' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'ListEnvironments' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
